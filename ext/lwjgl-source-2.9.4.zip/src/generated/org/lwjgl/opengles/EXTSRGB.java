/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTSRGB {

	/**
	 *  Accepted by the &lt;format&gt; and &lt;internalformat&gt; parameter of TexImage2D, and
	 *  TexImage3DOES.  These are also accepted by &lt;format&gt; parameter of
	 *  TexSubImage2D and TexSubImage3DOES:
	 */
	public static final int GL_SRGB_EXT = 0x8C40,
		GL_SRGB_ALPHA_EXT = 0x8C42;

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorage: 
	 */
	public static final int GL_SRGB8_ALPHA8_EXT = 0x8C43;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetFramebufferAttachmentParameteriv: 
	 */
	public static final int GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING_EXT = 0x8210;

	private EXTSRGB() {}
}
