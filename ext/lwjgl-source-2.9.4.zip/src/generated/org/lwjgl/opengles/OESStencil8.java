/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESStencil8 {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorageOES: 
	 */
	public static final int GL_STENCIL_INDEX8_OES = 0x8D48;

	private OESStencil8() {}
}
