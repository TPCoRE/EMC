/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBHalfFloatPixel {

	/**
	 *  Accepted by the &lt;type&gt; parameter of DrawPixels, ReadPixels,
	 *  TexImage1D, TexImage2D, TexImage3D, GetTexImage, TexSubImage1D,
	 *  TexSubImage2D, TexSubImage3D, GetHistogram, GetMinmax,
	 *  ConvolutionFilter1D, ConvolutionFilter2D, GetConvolutionFilter,
	 *  SeparableFilter2D, GetSeparableFilter, ColorTable, ColorSubTable,
	 *  and GetColorTable:
	 */
	public static final int GL_HALF_FLOAT_ARB = 0x140B;

	private ARBHalfFloatPixel() {}
}
