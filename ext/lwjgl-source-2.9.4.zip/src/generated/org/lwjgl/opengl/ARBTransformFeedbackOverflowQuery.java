/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTransformFeedbackOverflowQuery {

	/**
	 *  Accepted by the &lt;target&gt; parameter of BeginQuery, EndQuery,
	 *  BeginQueryIndexed, EndQueryIndexed, GetQueryiv, and GetQueryIndexediv:
	 */
	public static final int GL_TRANSFORM_FEEDBACK_OVERFLOW_ARB = 0x82EC,
		GL_TRANSFORM_FEEDBACK_STREAM_OVERFLOW_ARB = 0x82ED;

	private ARBTransformFeedbackOverflowQuery() {}
}
