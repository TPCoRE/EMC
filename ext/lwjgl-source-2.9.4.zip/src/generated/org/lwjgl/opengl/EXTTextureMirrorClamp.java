/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureMirrorClamp {

	/**
	 *  Accepted by the &lt;param&gt; parameter of TexParameteri and TexParameterf,
	 *  and by the &lt;params&gt; parameter of TexParameteriv and TexParameterfv,
	 *  when their &lt;pname&gt; parameter is TEXTURE_WRAP_S, TEXTURE_WRAP_T,
	 *  or TEXTURE_WRAP_R:
	 */
	public static final int GL_MIRROR_CLAMP_EXT = 0x8742,
		GL_MIRROR_CLAMP_TO_EDGE_EXT = 0x8743,
		GL_MIRROR_CLAMP_TO_BORDER_EXT = 0x8912;

	private EXTTextureMirrorClamp() {}
}
