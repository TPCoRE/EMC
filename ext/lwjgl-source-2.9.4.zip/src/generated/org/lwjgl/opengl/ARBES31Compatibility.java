/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBES31Compatibility {

	private ARBES31Compatibility() {}

	public static void glMemoryBarrierByRegion(int barriers) {
		GL45.glMemoryBarrierByRegion(barriers);
	}
}
