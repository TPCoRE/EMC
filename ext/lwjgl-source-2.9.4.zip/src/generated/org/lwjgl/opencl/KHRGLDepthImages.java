/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRGLDepthImages {

	/**
	 * cl_channel_order 
	 */
	public static final int CL_DEPTH_STENCIL = 0x10BE;

	/**
	 * cl_channel_type 
	 */
	public static final int CL_UNORM_INT24 = 0x10DF;

	private KHRGLDepthImages() {}
}
